# NTWR — Android Network Scanner

Starter Android project written in Kotlin. It performs bounded, non-destructive checks against a user-supplied HTTP/HTTPS target:

- TCP connectivity attempts against a fixed list of common ports.
- HTTP `HEAD` response status and selected security-header observations.
- Redirects are not followed; no exploit payloads, credential attacks, or fabricated findings are included.

## Open and run

1. Extract `NTWR-Android-Project.zip`.
2. Open the `NTWR` folder in Android Studio.
3. Use JDK 17 and install Android SDK Platform 35 when prompted.
4. Sync Gradle, then run the `app` configuration on an emulator or Android device.

This archive does not bundle Gradle wrapper scripts/JAR. Android Studio can import the Gradle project; alternatively, generate a wrapper locally with a compatible Gradle installation.

## Limitations

- An open TCP connection only means a connection succeeded from the device at scan time; it does not identify the service or prove a vulnerability.
- Missing HTTP headers are review indicators, not confirmed vulnerabilities. Some servers do not support `HEAD` correctly.
- Scan only systems you own or have explicit written permission to assess.
- The project files were created and packaged, but an Android build was not run in this environment. Verify Gradle sync and `assembleDebug` in Android Studio before relying on it.
