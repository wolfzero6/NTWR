package com.ntwr.scanner

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var targetInput: EditText
    private lateinit var output: TextView
    private lateinit var scanButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(16, 24, 39)
        window.navigationBarColor = Color.rgb(16, 24, 39)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 20)
            setBackgroundColor(Color.rgb(246, 248, 252))
        }
        val title = TextView(this).apply {
            text = "NTWR"
            textSize = 30f
            setTextColor(Color.rgb(16, 24, 39))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        val subtitle = TextView(this).apply {
            text = "Network Scanner · فاحص شبكي"
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, 4, 0, 20)
        }
        targetInput = EditText(this).apply {
            hint = "https://example.com"
            singleLine = true
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setTextColor(Color.BLACK)
        }
        val notice = TextView(this).apply {
            text = "استخدمه فقط مع الأنظمة التي تملكها أو لديك إذن صريح لاختبارها."
            textSize = 13f
            setTextColor(Color.DKGRAY)
            setPadding(0, 8, 0, 10)
        }
        scanButton = Button(this).apply { text = "بدء الفحص" }
        output = TextView(this).apply {
            text = "أدخل عنوان HTTP أو HTTPS مصرحًا به، ثم اضغط بدء الفحص."
            textSize = 14f
            setTextColor(Color.rgb(30, 41, 59))
            setPadding(0, 16, 0, 20)
            setTextIsSelectable(true)
        }
        val scroll = ScrollView(this).apply { addView(output) }
        root.addView(title)
        root.addView(subtitle)
        root.addView(targetInput, LinearLayout.LayoutParams(-1, -2))
        root.addView(notice)
        root.addView(scanButton)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        scanButton.setOnClickListener {
            val target = TargetUrl.parse(targetInput.text.toString())
            if (target == null) {
                output.text = "العنوان غير صالح. أدخل URL كاملًا يبدأ بـ http:// أو https://."
                return@setOnClickListener
            }
            scanButton.isEnabled = false
            output.text = "جارٍ الفحص… قد يستغرق بضع ثوانٍ."
            executor.execute {
                val report = NetworkScanner().scan(target)
                runOnUiThread {
                    output.text = report
                    scanButton.isEnabled = true
                }
            }
        }
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
