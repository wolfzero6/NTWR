package com.ntwr.scanner

import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

/** Bounded, non-destructive observations only. Use solely on authorized targets. */
class NetworkScanner(
    private val connectTimeoutMs: Int = 1500,
    private val readTimeoutMs: Int = 2500
) {
    private val commonPorts = listOf(21, 22, 25, 53, 80, 110, 143, 443, 445, 8080, 8443)

    fun scan(target: TargetUrl): String {
        val lines = mutableListOf<String>()
        lines += "NTWR — تقرير الفحص"
        lines += "الهدف: ${target.uri}"
        lines += "المضيف: ${target.host}"
        lines += "الوقت: ${java.time.Instant.now()}"
        lines += ""
        lines += "فحوصات اتصال TCP (منافذ شائعة فقط):"
        var reachable = 0
        for (port in commonPorts) {
            if (isTcpReachable(target.host, port)) {
                lines += "  متاح عبر TCP: $port"
                reachable++
            }
        }
        lines += "اكتملت ${commonPorts.size} محاولة اتصال؛ الاتصالات الناجحة: $reachable."
        lines += ""
        lines += "فحص استجابة HTTP والرؤوس الأمنية:"
        lines += checkHttp(target)
        lines += ""
        lines += "ملاحظة: النتائج ملاحظات تقنية وليست إثباتًا تلقائيًا لوجود ثغرة."
        lines += "لم تُستخدم نتائج مصطنعة أو حمولات استغلال أو هجمات كلمات مرور."
        return lines.joinToString("\n")
    }

    private fun isTcpReachable(host: String, port: Int): Boolean = try {
        Socket().use { it.connect(InetSocketAddress(host, port), connectTimeoutMs) }
        true
    } catch (_: Exception) {
        false
    }

    private fun checkHttp(target: TargetUrl): List<String> {
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL(target.uri.toString()).openConnection() as HttpURLConnection).apply {
                connectTimeout = connectTimeoutMs
                readTimeout = readTimeoutMs
                requestMethod = "HEAD"
                instanceFollowRedirects = false
                setRequestProperty("User-Agent", "NTWR/1.0 authorized-assessment")
            }
            val status = connection.responseCode
            val result = mutableListOf("  رمز HTTP: $status")
            val headers = listOf(
                "Strict-Transport-Security",
                "Content-Security-Policy",
                "X-Content-Type-Options",
                "X-Frame-Options",
                "Referrer-Policy"
            )
            for (header in headers) {
                result += if (connection.getHeaderField(header).isNullOrBlank()) {
                    "  الرأس غير ظاهر: $header (يحتاج مراجعة يدوية، وليس ثغرة مؤكدة)"
                } else {
                    "  الرأس موجود: $header"
                }
            }
            connection.getHeaderField("Location")?.takeIf { it.isNotBlank() }?.let {
                result += "  توجد وجهة إعادة توجيه؛ لم تتم متابعتها: $it"
            }
            result
        } catch (e: Exception) {
            listOf("  تعذر فحص HTTP: ${e.javaClass.simpleName}: ${e.message ?: "لا توجد تفاصيل"}")
        } finally {
            connection?.disconnect()
        }
    }
}
