package com.ntwr.scanner

import java.net.URI
import java.util.Locale

data class TargetUrl(val uri: URI, val host: String, val port: Int, val scheme: String) {
    companion object {
        fun parse(raw: String): TargetUrl? = try {
            val uri = URI(raw.trim())
            val scheme = uri.scheme?.lowercase(Locale.ROOT) ?: return null
            if (scheme != "http" && scheme != "https") return null
            val host = uri.host?.takeIf { it.isNotBlank() } ?: return null
            if (uri.userInfo != null) return null
            val port = if (uri.port > 0) uri.port else if (scheme == "https") 443 else 80
            if (port !in 1..65535) return null
            TargetUrl(uri, host, port, scheme)
        } catch (_: Exception) {
            null
        }
    }
}
